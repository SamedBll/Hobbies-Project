﻿Public Class Form1

    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick


        If (GetAsyncKeyState(1)) Then
            ListBox1.Items.Add("LeftClick")
        Else
            ListBox1.Items.Add("Nothing")
        End If

        If (GetAsyncKeyState(9)) Then
            ListBox1.Items.Add("TabPress")
        Else

        End If

        ListBox1.SelectedIndex = ListBox1.SelectedIndex + 1
    End Sub
End Class
