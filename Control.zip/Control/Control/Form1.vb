﻿
'Webcam

Public Class Form1
    Dim mousecontrol As Boolean
    Dim myPen1 As New System.Drawing.Pen(System.Drawing.Color.White, 2)
    Dim myPen2 As New System.Drawing.Pen(System.Drawing.Color.Yellow, 2)
    Dim myPen3 As New System.Drawing.Pen(System.Drawing.Color.Magenta, 2)
    Dim myPen4 As New System.Drawing.Pen(System.Drawing.Color.Cyan, 2)
    Dim myPen5 As New System.Drawing.Pen(System.Drawing.Color.Green, 2)
    Dim myPen6 As New System.Drawing.Pen(System.Drawing.Color.Red, 2)
    Dim myPen7 As New System.Drawing.Pen(System.Drawing.Color.Blue, 2)
    Dim Color1UpperR As Integer
    Dim Color1LowerR As Integer
    Dim Color1UpperG As Integer
    Dim Color1LowerG As Integer
    Dim Color1UpperB As Integer
    Dim Color1LowerB As Integer
    Dim Color2UpperR As Integer
    Dim Color2LowerR As Integer
    Dim Color2UpperG As Integer
    Dim Color2LowerG As Integer
    Dim Color2UpperB As Integer
    Dim Color2LowerB As Integer
    Dim Color3UpperR As Integer
    Dim Color3LowerR As Integer
    Dim Color3UpperG As Integer
    Dim Color3LowerG As Integer
    Dim Color3UpperB As Integer
    Dim Color3LowerB As Integer
    Dim findcolorPixel As Drawing.Color
    Dim Color1X(640) As Integer
    Dim Color1Y(480) As Integer
    Dim Color2X(640) As Integer
    Dim Color2Y(480) As Integer
    Dim Color3X(640) As Integer
    Dim Color3Y(480) As Integer
    Dim NewMousepointX As Integer
    Dim NewMousepointY As Integer
    Dim color1xavgfinal As Integer
    Dim color1yavgfinal As Integer
    Dim color2xavgfinal As Integer
    Dim color2yavgfinal As Integer
    Dim color3xavgfinal As Integer
    Dim color3yavgfinal As Integer
    Dim allavgX As Integer
    Dim allavgY As Integer
    Dim cameraselect As Integer = 0
    Dim invertX As Boolean
    Dim draw As Boolean = True

    Dim pic As New Drawing.Bitmap(640, 480)
    Public Touchless As New TouchlessLib.TouchlessMgr
    Public Camera2 As TouchlessLib.Camera = Touchless.Cameras.ElementAt(1)
    'Mouse commands
    Public Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Long, ByVal dx As Long, ByVal dy As Long, ByVal cButtons As Long, ByVal dwExtraInfo As Long)
    Public Const MOUSEEVENTF_LEFTDOWN = &H2 ' left button down
    Public Const MOUSEEVENTF_LEFTUP = &H4 ' left button up
    'Global Keyboard
    Public Const VK_CONTROL As Integer = &H11
    Public Const VK_Back As Integer = &H11
    Public Const VK_Forward As Integer = &H1B
    Public Declare Function RegisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer, ByVal fsModifiers As Integer, ByVal vk As Integer) As Integer
    Public Declare Function UnregisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer) As Integer
    Public Const WM_HOTKEY As Integer = &H312
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try

            pic = Touchless.CurrentCamera.GetCurrentImage

            Call FindCycle()

            Dim GFX6 As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(pic)

            If draw = True Then
                For i = 1 To 640
                    GFX6.DrawLine(myPen5, i - 1, Color1X(i - 1), i, Color1X(i))
                Next
                For i = 1 To 480
                    GFX6.DrawLine(myPen5, Color1Y(i - 1), i - 1, Color1Y(i), i)
                Next

                For i = 1 To 640
                    GFX6.DrawLine(myPen6, i - 1, Color2X(i - 1), i, Color2X(i))
                Next
                For i = 1 To 480
                    GFX6.DrawLine(myPen6, Color2Y(i - 1), i - 1, Color2Y(i), i)
                Next

                For i = 1 To 640
                    GFX6.DrawLine(myPen7, i - 1, Color3X(i - 1), i, Color3X(i))
                Next
                For i = 1 To 480
                    GFX6.DrawLine(myPen7, Color3Y(i - 1), i - 1, Color3Y(i), i)
                Next
            End If

            'Color 1 Math
            '==========================================
            Dim Color1MaxX As Integer = 0
            Dim color1maxXI As Integer = 0
            Dim color1maxY As Integer = 0
            Dim color1maxYI As Integer = 0
            Dim color1avgxloc(640) As Integer
            Dim color1avgyloc(640) As Integer

            For i = 0 To 639
                If Color1X(i) > Color1MaxX Then
                    Color1MaxX = Color1X(i)
                    color1maxXI = i
                End If
            Next
            For i = 0 To 479
                If Color1Y(i) > color1maxY Then
                    color1maxY = Color1Y(i)
                    color1maxYI = i
                End If
            Next

            Dim color1xmaxlower As Integer
            color1xmaxlower = Color1MaxX * 0.7
            Dim subcount As Integer = 0
            For i = 0 To 639
                If Color1X(i) > color1xmaxlower Then
                    color1avgxloc(subcount) = i
                    subcount = subcount + 1
                End If
            Next
            Dim color1xavg As Integer
            For i = 0 To subcount
                color1xavg = color1xavg + color1avgxloc(i)
            Next
            If subcount <> 0 Then
                color1xavgfinal = color1xavg \ subcount
            End If

            Dim color1ymaxlower As Integer
            color1ymaxlower = color1maxY * 0.7
            subcount = 0
            For i = 0 To 479
                If Color1Y(i) > color1ymaxlower Then
                    color1avgyloc(subcount) = i
                    subcount = subcount + 1
                End If
            Next
            Dim color1yavg As Integer
            For i = 0 To subcount
                color1yavg = color1yavg + color1avgyloc(i)
            Next
            If subcount <> 0 Then
                color1yavgfinal = color1yavg \ subcount
            End If

            If draw = True Then
                GFX6.DrawLine(myPen5, 640, 0, color1xavgfinal, color1yavgfinal)
            End If

            'Color 2 Math
            '==========================================
            Dim Color2MaxX As Integer = 0
            Dim color2maxXI As Integer = 0
            Dim color2maxY As Integer = 0
            Dim color2maxYI As Integer = 0
            Dim color2avgxloc(640) As Integer
            Dim color2avgyloc(640) As Integer

            For i = 0 To 639
                If Color2X(i) > Color2MaxX Then
                    Color2MaxX = Color2X(i)
                    color2maxXI = i
                End If
            Next
            For i = 0 To 479
                If Color2Y(i) > color2maxY Then
                    color2maxY = Color2Y(i)
                    color2maxYI = i
                End If
            Next

            Dim color2xmaxlower As Integer
            color2xmaxlower = Color2MaxX * 0.7
            subcount = 0
            For i = 0 To 639
                If Color2X(i) > color2xmaxlower Then
                    color2avgxloc(subcount) = i
                    subcount = subcount + 1
                End If
            Next
            Dim color2xavg As Integer
            For i = 0 To subcount
                color2xavg = color2xavg + color2avgxloc(i)
            Next
            If subcount <> 0 Then
                color2xavgfinal = color2xavg \ subcount
            End If

            Dim color2ymaxlower As Integer
            color2ymaxlower = color2maxY * 0.7
            subcount = 0
            For i = 0 To 479
                If Color2Y(i) > color2ymaxlower Then
                    color2avgyloc(subcount) = i
                    subcount = subcount + 1
                End If
            Next
            Dim color2yavg As Integer
            For i = 0 To subcount
                color2yavg = color2yavg + color2avgyloc(i)
            Next
            If subcount <> 0 Then
                color2yavgfinal = color2yavg \ subcount
            End If

            If draw = True Then
                GFX6.DrawLine(myPen6, 640, 0, color2xavgfinal, color2yavgfinal)
            End If

            'Color 3 Math
            '==========================================
            Dim color3MaxX As Integer = 0
            Dim color3maxXI As Integer = 0
            Dim color3maxY As Integer = 0
            Dim color3maxYI As Integer = 0
            Dim color3avgxloc(640) As Integer
            Dim color3avgyloc(640) As Integer

            For i = 0 To 639
                If Color3X(i) > color3MaxX Then
                    color3MaxX = Color3X(i)
                    color3maxXI = i
                End If
            Next
            For i = 0 To 479
                If Color3Y(i) > color3maxY Then
                    color3maxY = Color3Y(i)
                    color3maxYI = i
                End If
            Next

            Dim color3xmaxlower As Integer
            color3xmaxlower = color3MaxX * 0.5
            subcount = 0
            For i = 0 To 639
                If Color3X(i) > color3xmaxlower Then
                    color3avgxloc(subcount) = i
                    subcount = subcount + 1
                End If
            Next
            Dim color3xavg As Integer
            For i = 0 To subcount
                color3xavg = color3xavg + color3avgxloc(i)
            Next
            If subcount <> 0 Then
                color3xavgfinal = color3xavg \ subcount
            End If

            Dim color3ymaxlower As Integer
            color3ymaxlower = color3maxY * 0.5
            subcount = 0
            For i = 0 To 479
                If Color3Y(i) > color3ymaxlower Then
                    color3avgyloc(subcount) = i
                    subcount = subcount + 1
                End If
            Next
            Dim color3yavg As Integer
            For i = 0 To subcount
                color3yavg = color3yavg + color3avgyloc(i)
            Next
            If subcount <> 0 Then
                color3yavgfinal = color3yavg \ subcount
            End If

            If draw = True Then
                GFX6.DrawLine(myPen7, 640, 0, color3xavgfinal, color3yavgfinal)
            End If

            'Color Amount
            '==========================================
            Dim color1amount As Integer
            Dim color2amount As Integer
            Dim color3amount As Integer
            For i = 0 To 639
                color1amount = color1amount + Color1X(i)
                color2amount = color2amount + Color2X(i)
                color3amount = color3amount + Color3X(i)
            Next

            If color1amount > color2amount And color1amount > color3amount Then
                RadioButton1.BackColor = Color.Green
                RadioButton2.BackColor = Color.Transparent
                RadioButton3.BackColor = Color.Transparent
            End If
            If color2amount > color1amount And color2amount > color3amount Then
                RadioButton1.BackColor = Color.Transparent
                RadioButton2.BackColor = Color.Red
                RadioButton3.BackColor = Color.Transparent
            End If
            If color3amount > color1amount And color3amount > color2amount Then
                RadioButton1.BackColor = Color.Transparent
                RadioButton2.BackColor = Color.Transparent
                RadioButton3.BackColor = Color.Blue
            End If

            'Averaging and throwing out low finds
            '==========================================

            If color1amount <> 0 And color2amount <> 0 And color3amount <> 0 Then
                allavgX = (color1xavgfinal + color2xavgfinal + color3xavgfinal) / 3
                allavgY = (color1yavgfinal + color2yavgfinal + color3yavgfinal) / 3
            End If
            If color1amount = 0 Or (color1amount < 100 And color2amount > 100 And color3amount > 100) Then
                allavgX = (color2xavgfinal + color3xavgfinal) / 2
                allavgY = (color2yavgfinal + color3yavgfinal) / 2
            End If
            If color2amount = 0 Or (color1amount > 100 And color2amount < 100 And color3amount > 100) Then
                allavgX = (color1xavgfinal + color3xavgfinal) / 2
                allavgY = (color1yavgfinal + color3yavgfinal) / 2
            End If
            If color3amount = 0 Or (color1amount > 100 And color2amount > 100 And color3amount < 100) Then
                allavgX = (color1xavgfinal + color2xavgfinal) / 2
                allavgY = (color1yavgfinal + color2yavgfinal) / 2
            End If
            If color1amount = 0 And color2amount = 0 And color3amount <> 0 Then
                allavgX = color3xavgfinal
                allavgY = color3yavgfinal
            End If
            If color1amount = 0 And color2amount <> 0 And color3amount = 0 Then
                allavgX = color2xavgfinal
                allavgY = color2yavgfinal
            End If
            If color1amount <> 0 And color2amount = 0 And color3amount = 0 Then
                allavgX = color1xavgfinal
                allavgY = color1yavgfinal
            End If
            If color1amount = 0 And color2amount = 0 And color3amount = 0 Then
                allavgX = (color1xavgfinal + color2xavgfinal + color3xavgfinal) / 3
                allavgY = (color1yavgfinal + color2yavgfinal + color3yavgfinal) / 3
            End If




            'Line Drawing and coloring
            '==========================================

            If draw = True Then
                'White Triangle
                GFX6.DrawLine(myPen1, color1xavgfinal, color1yavgfinal, color2xavgfinal, color2yavgfinal)
                GFX6.DrawLine(myPen1, color2xavgfinal, color2yavgfinal, color3xavgfinal, color3yavgfinal)
                GFX6.DrawLine(myPen1, color1xavgfinal, color1yavgfinal, color3xavgfinal, color3yavgfinal)

                'Rectile
                GFX6.DrawLine(myPen1, allavgX - 10, allavgY, allavgX + 10, allavgY)
                GFX6.DrawLine(myPen1, allavgX, allavgY - 10, allavgX, allavgY + 10)

                PictureBox1.Image = pic
            End If


            ''Find Angle
            'Dim temptanx As Double
            'Dim temptany As Double
            'Dim tempangle1 As Double
            'Dim tempangle2 As Double
            'Dim FoundAngle As Integer

            'temptanx = (foundcenter.X - foundcenter2.X)
            'temptany = (foundcenter.Y - foundcenter2.Y)
            'If temptanx <> 0 And temptany <> 0 Then
            '    tempangle1 = Math.Atan2(temptany, temptanx)
            '    tempangle2 = (tempangle1 * (180 / Math.PI)) + 180

            'End If
            'FoundAngle = tempangle2
            'TextBox1.Text = foundcenter.ToString & " " & foundcenter2.ToString
            'TextBox2.Text = FoundAngle.ToString

            'Mouse Control
            '==========================================

            Dim MousepointX As Integer
            Dim MousepointY As Integer
            MousepointX = MousePosition.X
            MousepointY = MousePosition.Y
            Dim OffsetX As Integer
            Dim OffsetY As Integer
            Dim XScale As Decimal
            Dim YScale As Decimal
            Dim speedx As Integer
            Dim speedy As Integer
            YScale = My.Computer.Screen.Bounds.Height / 480
            XScale = My.Computer.Screen.Bounds.Width / 640

            If invertX = True Then
                OffsetX = (Math.Abs(640 - allavgX) * XScale) - MousepointX
            End If
            If invertX = False Then
                OffsetX = (allavgX * XScale) - MousepointX
            End If
            OffsetY = (allavgY * YScale) - MousepointY

            If mousecontrol = True Then
                speedx = Math.Abs(OffsetX) * 0.2
                speedy = Math.Abs(OffsetY) * 0.2

                If OffsetX > 0 Then
                    NewMousepointX = NewMousepointX + speedx
                End If
                If OffsetX < 0 Then
                    NewMousepointX = NewMousepointX - speedx
                End If
                If OffsetY > 0 Then
                    NewMousepointY = NewMousepointY + speedy
                End If
                If OffsetY < 0 Then
                    NewMousepointY = NewMousepointY - speedy
                End If


                Me.Cursor = New Cursor(Cursor.Current.Handle)
                Cursor.Position = New Point(NewMousepointX, NewMousepointY)
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub FindCycle()
        Try

            Dim rect As New Rectangle(0, 0, 640, 480)
            Dim bmpData As System.Drawing.Imaging.BitmapData = pic.LockBits(rect,
            Drawing.Imaging.ImageLockMode.ReadWrite, pic.PixelFormat)
            Dim ptr As IntPtr = bmpData.Scan0
            Dim bytes As Integer = bmpData.Stride * 480
            Dim rgbValues(bytes - 1) As Byte
            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes)

            Dim secondcounter As Integer
            Dim tempred As Integer
            Dim tempblue As Integer
            Dim tempgreen As Integer
            Dim tempalpha As Integer
            Dim yesno1 As Boolean
            Dim tempx As Integer
            Dim tempy As Integer

            secondcounter = 0
            yesno1 = True


            Array.Clear(Color1X, 0, Color1X.Length)
            Array.Clear(Color1Y, 0, Color1Y.Length)
            Array.Clear(Color2X, 0, Color2X.Length)
            Array.Clear(Color2Y, 0, Color2Y.Length)
            Array.Clear(Color3X, 0, Color3X.Length)
            Array.Clear(Color3Y, 0, Color3Y.Length)

            While secondcounter < rgbValues.Length
                tempblue = rgbValues(secondcounter)
                tempgreen = rgbValues(secondcounter + 1)
                tempred = rgbValues(secondcounter + 2)
                tempalpha = rgbValues(secondcounter + 3)
                tempalpha = 255

                tempy = ((secondcounter * 0.25) / 640)
                tempx = (secondcounter * 0.25) - (tempy * 640)
                If tempx < 0 Then
                    tempx = tempx + 640
                End If


                If tempred >= Color1LowerR And tempred <= Color1UpperR And tempgreen >= Color1LowerG And tempgreen <= Color1UpperG And tempblue >= Color1LowerB And tempblue <= Color1UpperB Then
                    If yesno1 = True Then
                        tempgreen = 255
                        tempred = 0
                        tempblue = 0
                    End If
                    Color1X(tempx) = Color1X(tempx) + 1
                    Color1Y(tempy) = Color1Y(tempy) + 1
                End If

                If tempred >= Color2LowerR And tempred <= Color2UpperR And tempgreen >= Color2LowerG And tempgreen <= Color2UpperG And tempblue >= Color2LowerB And tempblue <= Color2UpperB Then
                    If yesno1 = True Then
                        tempgreen = 0
                        tempred = 255
                        tempblue = 0
                    End If
                    Color2X(tempx) = Color2X(tempx) + 1
                    Color2Y(tempy) = Color2Y(tempy) + 1
                End If

                If tempred >= Color3LowerR And tempred <= Color3UpperR And tempgreen >= Color3LowerG And tempgreen <= Color3UpperG And tempblue >= Color3LowerB And tempblue <= Color3UpperB Then
                    If yesno1 = True Then
                        tempgreen = 0
                        tempred = 0
                        tempblue = 255
                    End If
                    Color3X(tempx) = Color3X(tempx) + 1
                    Color3Y(tempy) = Color3Y(tempy) + 1
                End If

                rgbValues(secondcounter) = tempblue
                rgbValues(secondcounter + 1) = tempgreen
                rgbValues(secondcounter + 2) = tempred
                rgbValues(secondcounter + 3) = tempalpha

                secondcounter = secondcounter + 4
            End While
            ' Copy the RGB values back to the bitmap
            System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes)

            ' Unlock the bits.
            pic.UnlockBits(bmpData)

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try


            Touchless.CurrentCamera = Camera2
            Touchless.CurrentCamera.CaptureHeight = 480
            Touchless.CurrentCamera.CaptureWidth = 640

            RegisterHotKey(Me.Handle, 9, 0, VK_Back)
            RegisterHotKey(Me.Handle, 10, 0, VK_Forward)

        Catch ex As Exception
            MsgBox("No Webcam Found. Install or plug in camera and reload program")
            Me.Close()
        End Try
    End Sub

    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown

        Dim picturemousexpos As Integer
        Dim picturemouseypos As Integer
        Dim picturemouse As System.Drawing.Point
        picturemousexpos = (((MousePosition.X - Me.Location.X) - PictureBox1.Location.X) - 4)
        picturemouseypos = ((MousePosition.Y - Me.Location.Y) - 30)
        picturemouse.X = picturemousexpos
        picturemouse.Y = picturemouseypos

        If picturemousexpos >= 0 And picturemousexpos <= 639 And picturemouseypos >= 0 And picturemouseypos <= 479 Then
            findcolorPixel = pic.GetPixel(picturemousexpos, picturemouseypos)
        End If

        If RadioButton1.Checked = True Then
            Color1UpperR = findcolorPixel.R + TrackBar1.Value
            Color1UpperG = findcolorPixel.G + TrackBar1.Value
            Color1UpperB = findcolorPixel.B + TrackBar1.Value
            Color1LowerR = findcolorPixel.R - TrackBar1.Value
            Color1LowerG = findcolorPixel.G - TrackBar1.Value
            Color1LowerB = findcolorPixel.B - TrackBar1.Value
        End If
        If RadioButton2.Checked = True Then
            Color2UpperR = findcolorPixel.R + TrackBar1.Value
            Color2UpperG = findcolorPixel.G + TrackBar1.Value
            Color2UpperB = findcolorPixel.B + TrackBar1.Value
            Color2LowerR = findcolorPixel.R - TrackBar1.Value
            Color2LowerG = findcolorPixel.G - TrackBar1.Value
            Color2LowerB = findcolorPixel.B - TrackBar1.Value
        End If
        If RadioButton3.Checked = True Then
            Color3UpperR = findcolorPixel.R + TrackBar1.Value
            Color3UpperG = findcolorPixel.G + TrackBar1.Value
            Color3UpperB = findcolorPixel.B + TrackBar1.Value
            Color3LowerR = findcolorPixel.R - TrackBar1.Value
            Color3LowerG = findcolorPixel.G - TrackBar1.Value
            Color3LowerB = findcolorPixel.B - TrackBar1.Value
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If mousecontrol = False Then
            mousecontrol = True
            Button1.ForeColor = Color.Red
        Else
            mousecontrol = False
            Button1.ForeColor = Color.Black
        End If
    End Sub

    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)

        If m.Msg = WM_HOTKEY Then
            Dim id As IntPtr = m.WParam
            Select Case (id.ToString)
                Case "9"
                    If mousecontrol = True Then
                        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
                    End If
                Case "10"
                    mousecontrol = False
                    Button1.ForeColor = Color.Black
            End Select
        End If

        MyBase.WndProc(m) 'Never Forget This

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        UnregisterHotKey(Me.Handle, 9) 'Remember to unregister the hotkey
        UnregisterHotKey(Me.Handle, 10) 'Remember to unregister the hotkey
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Color1UpperR = 0
        Color1LowerR = 0
        Color1UpperG = 0
        Color1LowerG = 0
        Color1UpperB = 0
        Color1LowerB = 0
        Color2UpperR = 0
        Color2LowerR = 0
        Color2UpperG = 0
        Color2LowerG = 0
        Color2UpperB = 0
        Color2LowerB = 0
        Color3UpperR = 0
        Color3LowerR = 0
        Color3UpperG = 0
        Color3LowerG = 0
        Color3UpperB = 0
        Color3LowerB = 0
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If cameraselect = 0 Then
            'Touchless.CurrentCamera = Camera2
            Touchless.CurrentCamera.CaptureHeight = 480
            Touchless.CurrentCamera.CaptureWidth = 640
            cameraselect = 1
        Else
            Touchless.CurrentCamera = Camera2
            Touchless.CurrentCamera.CaptureHeight = 480
            Touchless.CurrentCamera.CaptureWidth = 640
            cameraselect = 0
        End If

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        If CheckBox1.Checked = False Then
            invertX = False
        Else
            invertX = True
        End If

    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged

        If CheckBox2.Checked = False Then
            draw = False
        Else
            draw = True
        End If
    End Sub
End Class

