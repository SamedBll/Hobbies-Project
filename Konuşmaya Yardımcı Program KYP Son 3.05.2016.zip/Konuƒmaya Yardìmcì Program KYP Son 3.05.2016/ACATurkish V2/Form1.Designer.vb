﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button34 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button33
        '
        Me.Button33.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button33.Location = New System.Drawing.Point(201, 120)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(87, 27)
        Me.Button33.TabIndex = 141
        Me.Button33.Text = "Boşluk"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(106, 120)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(87, 27)
        Me.Button32.TabIndex = 140
        Me.Button32.Text = "Konuş (Speak)"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button31.Location = New System.Drawing.Point(24, 120)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(76, 27)
        Me.Button31.TabIndex = 139
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button30.Location = New System.Drawing.Point(352, 81)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(35, 33)
        Me.Button30.TabIndex = 138
        Me.Button30.Text = "Z"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button29.Location = New System.Drawing.Point(311, 81)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(35, 33)
        Me.Button29.TabIndex = 137
        Me.Button29.Text = "Y"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button28.Location = New System.Drawing.Point(270, 81)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(35, 33)
        Me.Button28.TabIndex = 136
        Me.Button28.Text = "V"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button27.Location = New System.Drawing.Point(229, 81)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(35, 33)
        Me.Button27.TabIndex = 135
        Me.Button27.Text = "Ü"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button26.Location = New System.Drawing.Point(188, 81)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(35, 33)
        Me.Button26.TabIndex = 134
        Me.Button26.Text = "U"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button25.Location = New System.Drawing.Point(147, 81)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(35, 33)
        Me.Button25.TabIndex = 133
        Me.Button25.Text = "T"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button24.Location = New System.Drawing.Point(106, 81)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(35, 33)
        Me.Button24.TabIndex = 132
        Me.Button24.Text = "Ş"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button23.Location = New System.Drawing.Point(65, 81)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(35, 33)
        Me.Button23.TabIndex = 131
        Me.Button23.Text = "S"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button22.Location = New System.Drawing.Point(24, 81)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(35, 33)
        Me.Button22.TabIndex = 130
        Me.Button22.Text = "R"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button21.Location = New System.Drawing.Point(373, 43)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(35, 33)
        Me.Button21.TabIndex = 129
        Me.Button21.Text = "P"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button20.Location = New System.Drawing.Point(332, 43)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(35, 33)
        Me.Button20.TabIndex = 128
        Me.Button20.Text = "Ö"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button19.Location = New System.Drawing.Point(291, 43)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(35, 33)
        Me.Button19.TabIndex = 127
        Me.Button19.Text = "O"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button18.Location = New System.Drawing.Point(250, 43)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(35, 33)
        Me.Button18.TabIndex = 126
        Me.Button18.Text = "N"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button17.Location = New System.Drawing.Point(211, 43)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(35, 33)
        Me.Button17.TabIndex = 125
        Me.Button17.Text = "M"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button16.Location = New System.Drawing.Point(170, 43)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(35, 33)
        Me.Button16.TabIndex = 124
        Me.Button16.Text = "L"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button15.Location = New System.Drawing.Point(129, 43)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(35, 33)
        Me.Button15.TabIndex = 123
        Me.Button15.Text = "K"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button14.Location = New System.Drawing.Point(88, 43)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(35, 33)
        Me.Button14.TabIndex = 122
        Me.Button14.Text = "J"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button13.Location = New System.Drawing.Point(46, 43)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(35, 33)
        Me.Button13.TabIndex = 121
        Me.Button13.Text = "İ"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button12.Location = New System.Drawing.Point(6, 43)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(35, 33)
        Me.Button12.TabIndex = 120
        Me.Button12.Text = "I"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button10.Location = New System.Drawing.Point(373, 4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(35, 33)
        Me.Button10.TabIndex = 119
        Me.Button10.Text = "H"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button9.Location = New System.Drawing.Point(332, 4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(35, 33)
        Me.Button9.TabIndex = 118
        Me.Button9.Text = "Ğ"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button8.Location = New System.Drawing.Point(291, 4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(35, 33)
        Me.Button8.TabIndex = 117
        Me.Button8.Text = "G"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button7.Location = New System.Drawing.Point(250, 4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(35, 33)
        Me.Button7.TabIndex = 116
        Me.Button7.Text = "F"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button6.Location = New System.Drawing.Point(211, 4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(35, 33)
        Me.Button6.TabIndex = 115
        Me.Button6.Text = "E"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button5.Location = New System.Drawing.Point(170, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(35, 33)
        Me.Button5.TabIndex = 114
        Me.Button5.Text = "D"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button4.Location = New System.Drawing.Point(129, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(35, 33)
        Me.Button4.TabIndex = 113
        Me.Button4.Text = "Ç"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button3.Location = New System.Drawing.Point(88, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(35, 33)
        Me.Button3.TabIndex = 112
        Me.Button3.Text = "C"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button2.Location = New System.Drawing.Point(47, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(35, 33)
        Me.Button2.TabIndex = 111
        Me.Button2.Text = "B"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button1.Location = New System.Drawing.Point(6, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(35, 33)
        Me.Button1.TabIndex = 110
        Me.Button1.Text = "A"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 600
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(294, 121)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(87, 27)
        Me.Button34.TabIndex = 143
        Me.Button34.Text = "Mouse"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(412, 152)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Türkçe Klavye"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button33 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button34 As Button
End Class
