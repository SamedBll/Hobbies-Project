﻿Public Class Form1
    'Samed Bille {samed.bille@gmail.com}
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Location = New Point(950, 125)
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Form2.Show()
        Form3.Show()
        Timer1.Start()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button31.Text = "ağrıyor-acıyor"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "a"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button31.Text = "aşım"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "b"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Button31.Text = "an"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "c"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Button31.Text = "ok"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "ç"
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Button31.Text = "irsek"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "d"
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Button31.Text = "elim"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "e"
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Button31.Text = "arklı"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "f"
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Button31.Text = "özüm"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "g"
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Button31.Text = "ğ"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "ğ"
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Button31.Text = "asta"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "h"
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Button31.Text = "lık"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "ı"
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Button31.Text = "yiyim"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "i"
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Button31.Text = "el"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "j"
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Button31.Text = "ol"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "k"
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Form2.TextBox1.Text = Form2.TextBox1.Text + "l"
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Button31.Text = "ercek"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "m"
    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Button31.Text = "asıl"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "n"
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Button31.Text = "ptik"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "o"
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        Button31.Text = "ğret"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "ö"
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        Button31.Text = "armak"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "p"
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        Button31.Text = "esim"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "r"
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        Button31.Text = "elam"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "s"
    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        Button31.Text = "imdi"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "ş"
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        Button31.Text = "amam"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "t"
    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        Button31.Text = "zun"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "u"
    End Sub

    Private Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        Button31.Text = "zgün"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "ü"
    End Sub

    Private Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click
        Button31.Text = "e"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "v"
    End Sub

    Private Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        Button31.Text = "eni"
        Form2.TextBox1.Text = Form2.TextBox1.Text + "y"
    End Sub

    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles Button30.Click
        Form2.TextBox1.Text = Form2.TextBox1.Text + "z"
    End Sub

    Private Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        Form2.TextBox1.Text = Form2.TextBox1.Text + Button31.Text
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        SendKeys.Send("{TAB}")
    End Sub

    Private Sub Button33_Click(sender As Object, e As EventArgs) Handles Button33.Click
        Form2.TextBox1.Text = Form2.TextBox1.Text + " "
    End Sub

    Private Sub Button32_Click(sender As Object, e As EventArgs) Handles Button32.Click
        Dim allelements As HtmlElementCollection = Form2.WebBrowser1.Document.All
        For Each webpageelement As HtmlElement In allelements

            If webpageelement.GetAttribute("id") = "gt-src-listen" Then
                webpageelement.InvokeMember("click")
            End If
            Me.TopMost = True
        Next
    End Sub

    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        Me.Close()
        Form2.Close()
        Form5.Show()
        Form3.Timer1.Stop()
        Form3.Timer2.Start()
    End Sub

    Private Sub Button36_Click(sender As Object, e As EventArgs) 
        Form2.TextBox1.Text = Form2.TextBox1.Text + "x"
    End Sub
    Private Sub Button35_Click(sender As Object, e As EventArgs) 
        Form2.TextBox1.Text = Form2.TextBox1.Text + "w"
    End Sub
End Class
