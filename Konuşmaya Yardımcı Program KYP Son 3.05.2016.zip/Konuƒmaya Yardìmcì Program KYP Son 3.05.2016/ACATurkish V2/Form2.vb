﻿Public Class Form2
    'Samed Bille {samed.bille@gmail.com}
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form1.Timer1.Stop()
        Me.Location = New Point(785, 0)
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        WebBrowser1.Navigate("https://translate.google.com.tr/#tr/en/")

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim allelements As HtmlElementCollection = WebBrowser1.Document.All
        For Each webpageelement As HtmlElement In allelements

            WebBrowser1.Document.GetElementById("source").SetAttribute("value", TextBox1.Text)
        Next
    End Sub

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted
        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = "Speech.exe"
        Process.Start(startInfo)
    End Sub
End Class