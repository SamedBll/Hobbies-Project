﻿Public Class Form5
    Public Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Long)
    'Samed Bille {samed.bille@gmail.com}
    Dim i As Integer
    Dim a As Integer
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TransparencyKey = Color.Transparent
        Me.BackColor = Color.White
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        i = i + 10
        Label1.Text = i
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        a = a - 10
        Label2.Text = a
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        i = i - 10
        Label1.Text = i
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(Label1.Text, Label2.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        a = a + 10
        Label2.Text = a
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Timer3.Start()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Timer2.Start()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(Label1.Text, Label2.Text)
        mouse_event(&H8)
        mouse_event(&H10)
        Timer2.Stop()
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = "Sol.exe"
        Process.Start(startInfo)
        Timer4.Start()
        Timer3.Stop()
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        SendKeys.Send("%{TAB}")
        Timer4.Stop()
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Form1.Show()
        Form2.Show()
        Form3.Timer2.Stop()
        Form2.WebBrowser1.Navigate("https://translate.google.com.tr/#tr/en/")
        Form3.Timer1.Start()
        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = "Speech.exe"
        Process.Start(startInfo)
        Me.Close()
    End Sub
End Class