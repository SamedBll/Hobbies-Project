﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Learn_English_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int art = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Okul";
        }

        private void timer3_Tick(object sender, EventArgs e)
        {

            if (label1.Text == "Okul" && textBox1.Text == "SCHOOL")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Ana Okulu";
            }
            if (label1.Text == "Ana Okulu" && textBox1.Text == "KINDERGARTEN")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Arkadaş Edinmek";
            }
            if (label1.Text == "Ana Okulu" && textBox1.Text == "PRE SCHOOL")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Arkadaş Edinmek";
            }
            if (label1.Text == "Arkadaş Edinmek" && textBox1.Text == "TO MAKE FRIENDS")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Çizmek";
            }
            if (label1.Text == "Çizmek" && textBox1.Text == "TO DRAW")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Sınıf";
            }
            if (label1.Text == "Sınıf" && textBox1.Text == "GRADE")
            {
                art++;
                textBox1.Clear();
                label1.Text = "İlkokul";
            }
            if (label1.Text == "İlkokul" && textBox1.Text == "ELEMENTARY SCHOOL")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Sınav";
            }
            if (label1.Text == "Sınav" && textBox1.Text == "EXAM")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Öğrenmek";
            }
            if (label1.Text == "Öğrenmek" && textBox1.Text == "LEARN")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Matematik";
            }
            if (label1.Text == "Matematik" && textBox1.Text == "MATHS")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Fen Bilimleri";
            }
            if (label1.Text == "Fen Bilimleri" && textBox1.Text == "SCIENCE")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Geometri";
            }
            if (label1.Text == "Geometri" && textBox1.Text == "GEOMETRY")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Fizik";
            }
            if (label1.Text == "Fizik" && textBox1.Text == "PHYSCS")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Tarih";
            }
            if (label1.Text == "Tarih" && textBox1.Text == "HISTORY")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Kimya";
            }
            if (label1.Text == "Kimya" && textBox1.Text == "CHEMISTRY")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Giriş Sınavı";
            }
            if (label1.Text == "Giriş Sınavı" && textBox1.Text == "ENTRANCE EXAM")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Lise";
            }
            if (label1.Text == "Lise" && textBox1.Text == "HIGH SCHOOL")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Ergenlik Dönemi";
            }
            if (label1.Text == "Ergenlik Dönemi" && textBox1.Text == "PUBERTY")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Ders";
            }
            if (label1.Text == "Ders" && textBox1.Text == "CLASS")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Not(Puan)";
            }
            if (label1.Text == "Not(Puan)" && textBox1.Text == "GRADE")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Üniversite";
            }
            if (label1.Text == "Üniversite" && textBox1.Text == "COLLEGE")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Olgun";
            }
            if (label1.Text == "Üniversite" && textBox1.Text == "UNIVERSITY")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Olgun";
            }
            else if (label1.Text == "Olgun" && textBox1.Text == "MATURE")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Sınavı Geçmek";
            }
            if (label1.Text == "Sınavı Geçmek" && textBox1.Text == "TO PASS EXAMS")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Sınavdan Başarısız Olmak";
            }
            if (label1.Text == "Sınavdan Başarısız Olmak" && textBox1.Text == "TO FAIL AN EXAM")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Sınava Tekrar Girmek";
            }
            if (label1.Text == "Sınava Tekrar Girmek" && textBox1.Text == "RESIT TO EXAM")
            {
                art++;
                textBox1.Clear();
                label1.Text = "Mezun Olmak";
            }
            if (label1.Text == "Mezun Olmak" && textBox1.Text == "GRADUATE")
            {
                art++;
                textBox1.Text = "ÇOK BAŞARILI";
                label1.Text = "ÇOK BAŞARILI";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = art.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label3.Text = textBox1.Text;
            label3.Text = label3.Text.ToLower();
                 }

        private void label1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Okul")
            {
                label3.Text = "s_h_ol";
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int a = 1;
            do
            {
                a++;
                label4.Text = a.ToString();
            }
            while (a >=99);

        }
    }
} 