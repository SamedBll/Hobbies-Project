﻿Public Class Form1
    Public Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Long)
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(1167, 148)
        mouse_event(&H2)
        mouse_event(&H4)
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TransparencyKey = Color.Transparent
        Me.BackColor = Color.White
    End Sub
End Class
