﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robo452
{
    public partial class Form1 : Form
    {

        [DllImport("user32.dll", EntryPoint = "mouse_event")]
        public static extern void mouse_event(long dwFlags);
        public Form1()
        {
            InitializeComponent();
        }
        [Flags]
  public enum MouseEventFlags
        {
            LEFTDOWN = 0x00000002,
            LEFTUP = 0x00000004
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void mouse_event(int lEFTDOWN, int v1, int v2, int v3, int v4)
        {
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Cursor = new Cursor(Cursor.Current.Handle);
            Cursor.Position = new Point(Convert.ToInt16.listBox1, listBox2.SelectedItem);
            mouse_event((int)(MouseEventFlags.LEFTDOWN), 0, 0, 0, 0);
            mouse_event((int)(MouseEventFlags.LEFTUP), 0, 0, 0, 0);
        }
        
        private void timer2_Tick(object sender, EventArgs e)
        {
            listBox1.Items.Add(MousePosition.X);
            listBox2.Items.Add(MousePosition.Y);
        }
    }
}
