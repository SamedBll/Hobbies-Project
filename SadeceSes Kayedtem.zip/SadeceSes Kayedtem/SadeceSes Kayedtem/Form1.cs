﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SadeceSes_Kayedtem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll")]
        private static extern int mciSendString(string MciComando, string MciRetorno, int MciRetornoLeng, int CallBack);
        private void button1_Click(object sender, EventArgs e)
        {
            mciSendString("open new type waveaudio alias Som", null, 0, 0);
            mciSendString("record Som", null, 0, 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mciSendString("pause Som", null, 0, 0);
            mciSendString("save Som mic.wav", null, 0, 0);
            mciSendString("close Som", null, 0, 0);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
      
    }
    }

