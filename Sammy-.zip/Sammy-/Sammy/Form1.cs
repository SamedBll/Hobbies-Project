﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;

namespace Sammy
{
    public partial class Form1 : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            button1.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Choices list = new Choices();
            list.Add(new string[] { "marobo","marhobo", "noshılsın","arhthık sus","sus"});
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(list);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += recEngine_SpeechRecognized;
        }

        private void recEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text == "marobo" || e.Result.Text=="marhobo")
            {
                pictureBox1.Visible = false;
                button2.PerformClick();
                merhaba();
            }
            else if (e.Result.Text == "noshılsın"|| e.Result.Text== "nha bher")
            {
                pictureBox1.Visible = false;
                button2.PerformClick();
            }
            else if (e.Result.Text== "arhthık sus" || e.Result.Text=="sus" || e.Result.Text=="kahpahn" || e.Result.Text=="kahpaht sheneni" )
            {
                Application.Exit();
                button2.PerformClick();
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            recEngine.RecognizeAsyncStop();
            button1.Enabled = true;
        }
        private void merhaba()
        {
            WMPLib.WindowsMediaPlayer wplayer = new WMPLib.WindowsMediaPlayer();
            wplayer.URL = "meraba.apv";
            wplayer.controls.play();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    } 
}
