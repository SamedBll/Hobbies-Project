﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;

namespace Sammy
{
    public partial class Form2 : Form
    {
        Form1 frm1 = new Form1();
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            frm1.Show();
            Choices list = new Choices();
            list.Add(new string[] { "hay"});
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(list);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += recEngine_SpeechRecognized;
            recEngine.RecognizeAsync(RecognizeMode.Multiple);
        }

        private void recEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text == "hay")
            {
                frm1.pictureBox1.Visible = true;
               frm1.button1.PerformClick(); 
            }
        }
    }
}
