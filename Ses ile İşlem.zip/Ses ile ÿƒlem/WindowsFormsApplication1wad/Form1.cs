﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Threading;

namespace WindowsFormsApplication1wad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadGrammar();
            StartRecognition();

        }
        private SpeechRecognitionEngine recognizer = new SpeechRecognitionEngine();
        public void LoadGrammar()
        {
            Choices choices = new Choices(new string[] { "Light", "Hi" ,"Maraba"});
            GrammarBuilder grammarBuilder = new GrammarBuilder(choices);

            grammarBuilder.Culture = System.Globalization.CultureInfo.GetCultureInfoByIetfLanguageTag("en-US");
            Grammar grammar = new Grammar(grammarBuilder);
            recognizer.LoadGrammar(grammar);
        }
        private void StartRecognition()
        { // Belirli sesleri tanıma işlemindeki ana olaylar

           
            recognizer.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(recognizer_SpeechRecognized);

            recognizer.RecognizeCompleted += new EventHandler<RecognizeCompletedEventArgs>(recognizer_RecognizeCompleted);

       

            Thread t1 = new Thread(delegate ()
            {
                recognizer.SetInputToDefaultAudioDevice();
                recognizer.RecognizeAsync(RecognizeMode.Single);
            });
            t1.Start();
        }
 

        private void recognizer_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text.IndexOf("Light") > -1)
            {
                System.Diagnostics.Process.Start("wwww.facebook.com");
            }
            else if (e.Result.Text == "Hi")
            {
                HtmlElementCollection allelements = webBrowser1.Document.All;
                foreach (HtmlElement webpageelement in allelements)
                {
                    webBrowser1.Document.GetElementById("source").SetAttribute("value", "meraba");
                    timer1.Start();
                }
                label1.Text = e.Result.Text;
            }
            else if ( e.Result.Text == "Maraba")
            {
                System.Diagnostics.Process.Start("www.google.com");
            }
        }

   
     
        private void recognizer_RecognizeCompleted(object sender, RecognizeCompletedEventArgs e)
        {
            recognizer.RecognizeAsync();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            HtmlElementCollection allelements = webBrowser1.Document.All;
            foreach (HtmlElement webpageelement in allelements)
                if ((webpageelement.GetAttribute("id") == "gt-src-listen"))
            {
                webpageelement.InvokeMember("click");
            }
            timer1.Stop();
        }
    }
}
