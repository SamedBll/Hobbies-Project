﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Runtime.InteropServices;
using System.IO;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll")]
        private static extern int mciSendString(string MciComando, string MciRetorno, int MciRetornoLeng, int CallBack);
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void Engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            DialogResult res= MessageBox.Show("Algılanan kelime :" + e.Result.Text);
            if ( res == DialogResult.OK)
            {
                Application.Restart(); 
            }
            }

        private void button1_Click(object sender, EventArgs e)
        {
            mciSendString("open new type waveaudio alias Som", null, 0, 0);
            mciSendString("record Som", null, 0, 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mciSendString("pause Som", null, 0, 0);
            mciSendString("save Som +mic.wav", null, 0, 0);
            mciSendString("close Som", null, 0, 0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SpeechRecognitionEngine engine = new SpeechRecognitionEngine();

            engine.SetInputToWaveFile("+mic.wav");

            Choices liste = new Choices();
            liste.Add(new string[] {"Merhaba" });

            GrammarBuilder gb = new GrammarBuilder();
            gb.Append(liste);

            Grammar g = new Grammar(gb);
            engine.LoadGrammar(g);

            engine.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(Engine_SpeechRecognized);

            engine.Recognize();
          
        }
       }
}
