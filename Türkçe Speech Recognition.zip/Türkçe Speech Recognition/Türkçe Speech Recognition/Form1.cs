﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using NAudio;
using NAudio.CoreAudioApi;
using System.Runtime.InteropServices;


namespace Türkçe_Speech_Recognition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MMDeviceEnumerator de = new MMDeviceEnumerator();
            var devices = de.EnumerateAudioEndPoints(DataFlow.All, DeviceState.Active);
            comboBox1.Items.AddRange(devices.ToArray());
        }
        [DllImport("winmm.dll")]
        private static extern int mciSendString(string MciComando, string MciRetorno, int MciRetornoLeng, int CallBack);

        private void button1_Click(object sender, EventArgs e)
        {
            SpeechRecognitionEngine engine = new SpeechRecognitionEngine();

            engine.SetInputToWaveFile("mic.wav");

            Choices liste = new Choices();
            liste.Add(new string[] { textBox1.Text});

            GrammarBuilder gb = new GrammarBuilder();
            gb.Append(liste);

            Grammar g = new Grammar(gb);
            engine.LoadGrammar(g);

            engine.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(Engine_SpeechRecognized);

            engine.Recognize();
        }
        private void Engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            DialogResult res = MessageBox.Show("Algılanan kelime :" + e.Result.Text);
            if (res == DialogResult.OK)
            {
                Application.Restart();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem  != null )
            {
                var device = (MMDevice)comboBox1.SelectedItem;
                progressBar1.Value = (int)(Math.Round(device.AudioMeterInformation.MasterPeakValue * 100));
            }
            label1.Text = progressBar1.Value.ToString();
                   }

        private void button2_Click(object sender, EventArgs e)
        {
            mciSendString("open new type waveaudio alias Som", null, 0, 0);
            mciSendString("record Som", null, 0, 0);
            timer1.Start();
            timer2.Start();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 5)
            {
                mciSendString("pause Som", null, 0, 0);
                mciSendString("save Som mic.wav", null, 0, 0);
                mciSendString("close Som", null, 0, 0);
                timer2.Stop();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 1;
        }
    }
}
